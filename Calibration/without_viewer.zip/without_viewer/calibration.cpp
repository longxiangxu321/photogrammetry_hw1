/**
 * Copyright (C) 2015 by Liangliang Nan (liangliang.nan@gmail.com)
 * https://3d.bk.tudelft.nl/liangliang/
 *
 * This file is part of Easy3D. If it is useful in your research/work,
 * I would be grateful if you show your appreciation by citing it:
 * ------------------------------------------------------------------
 *      Liangliang Nan.
 *      Easy3D: a lightweight, easy-to-use, and efficient C++
 *      library for processing and rendering 3D data. 2018.
 * ------------------------------------------------------------------
 * Easy3D is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 3
 * as published by the Free Software Foundation.
 *
 * Easy3D is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "calibration.h"

#include <easy3d/core/surface_mesh.h>
#include <easy3d/util/string.h>
#include <easy3d/fileio/resources.h>
#include <easy3d/util/dialogs.h>


using namespace easy3d;


Calibration::Calibration(const std::string& title)
{
    open();
    if (points_2d_.size() < 6 || points_3d_.size() < 6) {
        LOG(ERROR) << "expecting at least 6 pairs of 3D/2D corresponding points";
        return;
    }

    double fx, fy, cx, cy, skew;
    Matrix33 R;
    Vector3D t;
    bool success = calibration(points_3d_, points_2d_, fx, fy, cx, cy, skew, R, t);
    if (!success) {
        LOG(ERROR) << "calibration failed (return 'true' after implementing the calibration(...) function)";
    }
}


bool Calibration::open() {
    const std::string title("Please choose a file containing the 3D-2D correspondences");
    const std::string default_path(resource::directory() + "/data");
    const std::vector<std::string> &filters = {
            "Correspondences File (*.txt)", "*.txt",
    };

    const std::string &file_name = dialog::open(title, default_path, filters);
    if (file_name.empty())
        return false;

    points_2d_.clear();
    points_3d_.clear();

    FILE *correspondence_file = fopen(file_name.c_str(), "r");
    if (!correspondence_file) {
        LOG(ERROR) << "could not open file: " << file_name;
        return false;
    }

    char line[256];
    double x, y, z, xx, yy;
    while (fgets(line, 256, correspondence_file) != nullptr) {
        if (5 == sscanf(line, "%lf %lf %lf %lf %lf", &x, &y, &z, &xx, &yy)) {
            points_3d_.emplace_back(Vector3D(x, y, z));
            points_2d_.emplace_back(Vector2D(xx, yy));
        }
    }

    // print the points for the students to check if the data has been correctly loaded.
    std::cout << "the correspondences loaded from the file are: " << std::endl;
    for (int i=0; i<points_2d_.size(); ++i) {
        std::cout << "\t" << i << ": (" << points_3d_[i] << ") <-> (" << points_2d_[i] << ")" << std::endl;
    }

    return false;
}